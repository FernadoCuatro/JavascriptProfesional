const hello = () => {
    return 'hello!'
}

export default hello;