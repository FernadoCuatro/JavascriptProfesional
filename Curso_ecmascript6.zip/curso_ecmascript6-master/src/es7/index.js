let numbers = [1, 2, 3, 7, 8, 9];

if (numbers.includes(0)) {
    console.log('Si se encuentra el valor 7');
} else {
    console.log('No se encuentra');
}

let base = 4;
let exponent = 3;
let result = base ** exponent;
console.log(result);