// Objetos

// los objetos se manejan von propiedades
// las propiedades es una combinación de palabras clave y valores
var miAuto = {
  marca: 'Range Rover',
  modelo: 'Velar',
  annio: '2020',
};

miAuto[marca]; // En este momento estamos accediendo al valor de la marca: 'Range Rover'