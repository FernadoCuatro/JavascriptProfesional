var elCaso = 1;

switch (elCaso) {
  case 1:
    console.log('Soy uno');
    break;
  case 2:
    console.log('Soy dos');
    break;
  case 3:
    console.log('Soy tres');
    break;
  case 4:
    console.log('Soy cuatro');
    break;
  case 5:
    console.log('Soy cinco');
    break;
  default:
    console.log('Soy otro número');
}