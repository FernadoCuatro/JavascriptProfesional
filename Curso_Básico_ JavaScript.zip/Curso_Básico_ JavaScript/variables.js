/*
  - Es la representación de algun lugar en memoria que vamos a reservar para guardar un valor
  - var es la palabra reservada de JS para entender que es una variable
  - ESTADOS DE UNA VARIABLE:
      -DECLARAR
      -INICIALIZAR
*/

var nombre; // declarar

nombre // undefined, debido a que aún no hay valor, no inicializada

nombre = 'Valentina'; // inicializar