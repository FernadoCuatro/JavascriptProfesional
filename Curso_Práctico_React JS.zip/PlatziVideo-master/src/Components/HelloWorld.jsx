import React from 'react';
import '../assets/styles/App.scss';

const HelloWorld = () => (
  <h1>Hola Mundo mundito</h1>
);

export default HelloWorld;
