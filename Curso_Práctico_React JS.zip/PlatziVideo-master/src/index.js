import React from 'react';
import ReactDOM from 'react-dom';
//import HelloWorld from './Components/HelloWorld'
import App from './containers/App';
import './assets/styles/App.scss';

ReactDOM.render(<App />, document.getElementById('app'));
