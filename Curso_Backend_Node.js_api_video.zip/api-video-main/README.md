<!-- Headings -->
# About this

It's a simple API that manage a DB from Mongo:Atlas, and has its CRUD, using the methods of the requests usually used in apis, get, put, post, etc.

Documentation in notion
[video-API]('https://www.notion.so/escuelajs/video-API-Express-js-74118d44714545569006b9075b5472bc')